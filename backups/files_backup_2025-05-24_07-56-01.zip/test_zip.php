<?php
if (class_exists('ZipArchive')) {
    echo "✅ ZipArchive is available\n";
    
    // Test creating a zip file
    $zip = new ZipArchive();
    $result = $zip->open('test.zip', ZipArchive::CREATE);
    
    if ($result === TRUE) {
        echo "✅ ZipArchive can create files\n";
        $zip->close();
        unlink('test.zip'); // Clean up
    } else {
        echo "❌ ZipArchive cannot create files. Error: $result\n";
    }
} else {
    echo "❌ ZipArchive is NOT available\n";
    echo "You need to enable the zip extension in PHP\n";
}

echo "\nPHP Extensions related to zip:\n";
$extensions = get_loaded_extensions();
foreach ($extensions as $ext) {
    if (stripos($ext, 'zip') !== false) {
        echo "- $ext\n";
    }
}
?>